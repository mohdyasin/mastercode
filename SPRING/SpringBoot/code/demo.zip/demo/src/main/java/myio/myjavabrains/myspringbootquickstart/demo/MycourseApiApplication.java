package myio.myjavabrains.myspringbootquickstart.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MycourseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MycourseApiApplication.class, args);
	}
}
